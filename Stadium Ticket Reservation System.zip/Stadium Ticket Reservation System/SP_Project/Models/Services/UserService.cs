﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public class UserService : IUserService
    {
        
        private readonly ApplicationDbContext _context;
        public string name;
        public UserService()
        {

        }
        public UserService(ApplicationDbContext context)
        {
            _context = context;
        }
        public void Add(User u)
        {
            _context.tblUser.Add(u);
            _context.SaveChanges();
        }

        public string GetRole(User u)
        {
             name = u.userName;
            var pass = u.password;
            //User myUser = _context.tblUser.FirstOrDefault(user => user.userName == name && user.password == pass);
            string role = _context.tblUser.Where(user => user.userName == name && user.password == pass).Select(user => user.role).SingleOrDefault();
            return role;
        }
        public List<User> GetAllUser()
        {
            var users = _context.tblUser.ToList();
            /* var q = from e in _context.tblEvent
                     select new { e.eventid,e.name,e.eventdate,e.eventtime };

             var model = q.ToList();*/
            return (users);
        }

        public List<User> GetReservation()
        {
            /*var r = (from r in _context.tblReservation
                     join u in _context.tblUser
                     on r.user equals u.id
                     join t in _context.tblTicket
                     on r.ticket equals t.ticketid
                     join e in _context.tblEvent
                     on t.eventt equals e.eventid
                     join s in _context.tblSeat
                     on r.resid equals s.reservation

                     where u.userName == name
                     select new
                     {
                         r.resid,
                         r.resdate,
                         r.numberofreservations,
                         u.userName,
                         t.ticketid,
                         t.amount,
                         t.tickettype,
                         e.name,
                         s.seat,
                         s.seattype
                     }).ToList();*/
            var users = _context.tblUser.ToList();
            return (users);
        }
        public int NoOfAdmin()
        {
            throw new NotImplementedException();
        }

        public int NoOfUser()
        {
            throw new NotImplementedException();
        }

        public string UserByEvent(Event e)
        {
            throw new NotImplementedException();
        }
    }
}
