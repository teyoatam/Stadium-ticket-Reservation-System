﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SP_Project.Models.Services
{
    public class SeatService : ISeatService
    {
        private readonly ApplicationDbContext _context;
        public SeatService(ApplicationDbContext context)
        {
            _context = context;
        }
        public Seat GetSeatsById(int id)
        {
            var t = _context.tblSeat.Find(id);
            return t;
            
        }
        public List<Seat> AvailableSeat()
        {
            /*var result = from t in _context.tblSeat
                         where t.reservation.Equals(null)
                         select new 
                         {
                             seatnumber = t.seatnumber,
                             seattype = t.seattype
                             
                         };*/

            var t = _context.tblSeat.Where(a => a.available=="no").ToList();
           

             /*var seats = _context.tblSeat.FromSqlRaw("spDisplaySeat")
                 .ToList();
            return seats;
            int value = null;
            
            var b = _context.tblSeat.Where(a => a.reservation == value).ToList();
            return (b);*/
            /*DBLayer dbl = new DBLayer();
            DataTable a=dbl.DisplaySeat();*/
            return t;
        }
    }
}
