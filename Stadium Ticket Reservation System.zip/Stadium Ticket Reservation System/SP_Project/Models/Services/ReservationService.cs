﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public class ReservationService : IReservationService
    {
        
        private readonly ApplicationDbContext _context;
        public ReservationService(ApplicationDbContext context)
        {
            _context = context;
        }
         
        public List<Reservation> DisplayReservationByname(string name)
        {
            /*var person = _context.tblReservation.Join(_context.tblUser,
                  p => p.user,
                  e => e.id,
                  (p, e) => new
                  {
                      ResId=p.resid,
                      ResDate=p.resDate,
                      ResTime=p.resTime,
                      Username=e.userName
                  }.Where(e.userName == name).Select
               .Select new(x => new AppInformation()
                {
                    ResId = p.resid,
                    ResDate = p.resDate,
                    ResTime = p.resTime,
                    Username = e.userName
                })
            .ToList();*/
            var r = (from p in _context.tblReservation
                          join e in _context.tblUser
                          on p.users equals e.id
                          join t in _context.tblSeat
                          on p.resid equals t.reservation
                          where e.userName == name
                          select new Reservation()
                          {
                              resid = p.resid,
                              resDate = p.resDate,
                              resTime = p.resTime,
                              ticket=p.ticket
                              
                          }).ToList();

           /* var seats = _context.tblReservation.FromSqlRaw("pDisplayUserreservation @p0")
                .ToList();*/
            return r;
        }

        public Reservation GetById(int id)
        {
            var exsitingR = _context.tblReservation.Find(id);
            return exsitingR;
        }
        public void Delete(int id)
        {
            var exsitingReservation = _context.tblReservation.Find(id);
            _context.tblReservation.Remove(exsitingReservation);
            _context.SaveChanges();

        }
        public void Add(Reservation r)
        {
            _context.tblReservation.Add(r);
            _context.SaveChanges();
        }
        public Reservation Update(Reservation r)
        {
            _context.Update(r);
            _context.SaveChanges();
            return r;
        }
    }
}
