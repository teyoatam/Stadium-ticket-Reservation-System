﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public interface ITicketService
    {
        List<Ticket> DisplayTicket(int id);
        List<Ticket> GetAll();

        void Add(Ticket e);
        Ticket Update(Ticket e);
        void Delete(int id);
        Ticket GetById(int id);
    }
}
