﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public interface IReservationService
    {
        List<Reservation> DisplayReservationByname(string name);
        Reservation GetById(int id);
        void Delete(int id);
        void Add(Reservation r);
       Reservation Update(Reservation r);
    }
}
