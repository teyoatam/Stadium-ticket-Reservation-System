﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public class EventService : IEventService
    {
        private readonly ApplicationDbContext _context;
        public EventService(ApplicationDbContext context)
        {
            _context = context;
        }
       

        public void Add(Event e)
        {
            _context.tblEvent.Add(e);
            _context.SaveChanges();
        }

        public List<Event> GetAll()
        {
            var events = _context.tblEvent.ToList();
            /* var q = from e in _context.tblEvent
                     select new { e.eventid,e.name,e.eventdate,e.eventtime };

             var model = q.ToList();*/
            return (events);
        }

        public Event GetById(int id)
        {
            var exsitingEvent = _context.tblEvent.Find(id);
            return exsitingEvent;

        }

        public Event Update(Event e)
        {
            _context.Update(e);
            _context.SaveChanges();
            return e;
        }

        public void Delete(int id)
        {
            var exsitingEvent = _context.tblEvent.Find(id);
            _context.tblEvent.Remove(exsitingEvent);
            _context.SaveChanges();

        }
    }
}
