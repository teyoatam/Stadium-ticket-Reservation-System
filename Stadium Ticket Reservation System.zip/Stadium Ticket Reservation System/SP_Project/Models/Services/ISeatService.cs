﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public interface ISeatService
    {
        List<Seat> AvailableSeat();
        Seat GetSeatsById(int id);
    }
}
