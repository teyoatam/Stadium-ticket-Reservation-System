﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public interface IEventService
    {
        void Add(Event e);
        Event Update(Event e);
        void Delete(int id);
        List<Event> GetAll();
      
        Event GetById(int id);
    }
}
