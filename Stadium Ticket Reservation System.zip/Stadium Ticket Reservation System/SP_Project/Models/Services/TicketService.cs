﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models.Services
{
    public class TicketService : ITicketService
    {
        private readonly ApplicationDbContext _context;
        public TicketService(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Add(Ticket e)
        {
            _context.tblTicket.Add(e);
            _context.SaveChanges();
        }

        public List<Ticket> GetAll()
        {
            var tickets = _context.tblTicket.ToList();
            /* var q = from e in _context.tblEvent
                     select new { e.eventid,e.name,e.eventdate,e.eventtime };

             var model = q.ToList();*/
            return (tickets);
        }

        public Ticket GetById(int id)
        {
            var exsitingTicket = _context.tblTicket.Find(id);
            return exsitingTicket;

        }

        public Ticket Update(Ticket e)
        {
            _context.Update(e);
            _context.SaveChanges();
            return e;
        }

        public void Delete(int id)
        {
            var exsitingTicket = _context.tblTicket.Find(id);
            _context.tblTicket.Remove(exsitingTicket);
            _context.SaveChanges();

        }

        public List<Ticket> DisplayTicket(int id)
        {
            

            var t=(from p in _context.tblTicket
                  join e in _context.tblReservation
                  on p.ticketid equals e.ticket

                  where p.ticketid != e.ticket && p.eventt == id
                  select new Ticket()
                  {
                      ticketid=p.ticketid,
                      tickettype=p.tickettype,
                      amount=p.amount
                  }).ToList();
            return t;
            
        }
      
    }
}
