﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models
{
    public class Seat
    {
        [Key]
        public int seatnumber { get; set; }
        public string seattype { get; set; }
        
        public string available { get; set; } 
        public int? reservation { get; set; }
    }
}
