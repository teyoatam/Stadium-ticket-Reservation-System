﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models
{
    public class Reservation
    {
        [Key]
        public int resid { get; set; }
        public string resDate { get; set; }
        public string resTime { get; set; }
        public int numberofreservation { get; set; }
        public int users { get; set; }
        public int ticket { get; set; }
    }
}
