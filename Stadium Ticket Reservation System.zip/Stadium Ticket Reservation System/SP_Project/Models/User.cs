﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models
{
    public class User
    {
        [Key]
        public int id { get; set; }
        [Required(ErrorMessage = "Email is required.")]
        [RegularExpression("/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:.[a-zA-Z0-9-]+)*$/.")]
        public string email { get; set; }
        [Required(ErrorMessage = "UserName is required.")]
        public string userName { get; set; }
        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        [Compare("Password", ErrorMessage = "Please confirm your password")]
        public string confirmpassword { get; set; }
        public string role { get; set; }
        [Required(ErrorMessage = "First Name is required.")]
        public string firstname { get; set; }
        [Required(ErrorMessage = "Last Name is required.")]
        public string lastname { get; set; }
        

    }
}
