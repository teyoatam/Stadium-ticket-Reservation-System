﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models
{
    public class Ticket
    {
        [Key]
        public int ticketid { get; set; }
        public string tickettype { get; set; }
        public int amount { get; set; }
        public int eventt { get; set; }
    }
}
