﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models
{
    public class ApplicationDbContext :DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
          : base(options)
        {
        }

        public DbSet<User> tblUser { get; set; }
        public DbSet<Event> tblEvent { get; set; }
        public DbSet<Reservation> tblReservation { get; set; }
        public DbSet<Ticket> tblTicket { get; set; }
        public DbSet<Seat> tblSeat { get; set; }
        public DbSet<Payment> tblPayment { get; set; }

       
    }
}
