﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Models
{
    public class Payment
    {
        
            [Key]
            public int paymentid { get; set; }
            public string paymentdate { get; set; }
            public int amount { get; set; }
            public int ticket { get; set; }

        
    }
}
