﻿using Microsoft.AspNetCore.Mvc;
using SP_Project.Models;
using SP_Project.Models.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Controllers
{
    public class AdminController : Controller
    {
        public readonly IEventService _serviceEvent;
        public readonly IUserService _serviceUser;
        public readonly ITicketService _serviceTicket;
        public AdminController(IEventService service1, IUserService service2, ITicketService service3)
        {
            _serviceEvent = service1;
            _serviceUser = service2;
            _serviceTicket = service3;
        }
        public IActionResult Home()
        {

            return View();
        }



        public IActionResult EventList()
        {
            var data = _serviceEvent.GetAll();
            return View(data);

        }

        public IActionResult UserList()
        {
            var user = _serviceUser.GetAllUser();
            return View(user);
        }
        public IActionResult CreateUser()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateUser(User u)
        {
            _serviceUser.Add(u);

            return RedirectToAction("UserList");
        }

        public IActionResult EventDetails(int id)
        {
            var data = _serviceEvent.GetById(id);
            return View(data);

        }
        public IActionResult EventCreate()
        {
            return View();
        }
        [HttpPost]
        public IActionResult EventCreate(Event e)
        {
            _serviceEvent.Add(e);

            return RedirectToAction("EventList");
        }
        public IActionResult EventEdit(int id)
        {
            var data = _serviceEvent.GetById(id);
            return View(data);
        }
        [HttpPost]
        public IActionResult EventEdit(int id, Event e)
        {
            _serviceEvent.Update(e);
            return RedirectToAction("EventList");
        }
        public IActionResult EventDelete(int id)
        {
            var hold = _serviceEvent.GetById(id);
            return View(hold);
        }
        [HttpPost]
        public IActionResult EventDelete(int id, Event e)
        {
            _serviceEvent.Delete(id);
            return RedirectToAction("EventList");
        }





        public IActionResult TicketList()
        {
            var data = _serviceTicket.GetAll();
            return View(data);
        }
        public IActionResult TicketCreate()
        {
            return View();
        }
        [HttpPost]
        public IActionResult TicketCreate(Ticket e)
        {
            _serviceTicket.Add(e);

            return RedirectToAction("TicketList");
        }
        public IActionResult TicketEdit(int id)
        {
            var data = _serviceTicket.GetById(id);
            return View(data);
        }
        [HttpPost]
        public IActionResult TicketEdit(int id, Ticket e)
        {
            _serviceTicket.Update(e);
            return RedirectToAction("TicketList");
        }
        public IActionResult TicketDelete(int id)
        {
            var hold = _serviceTicket.GetById(id);
            return View(hold);
        }
        [HttpPost]
        public IActionResult TicketDelete(int id, Ticket e)
        {
            _serviceEvent.Delete(id);
            return RedirectToAction("TicketList");
        }
    }
}
