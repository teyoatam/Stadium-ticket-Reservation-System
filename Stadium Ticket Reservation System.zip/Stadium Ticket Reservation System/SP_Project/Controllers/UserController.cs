﻿using Microsoft.AspNetCore.Mvc;
using SP_Project.Models;
using SP_Project.Models.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Controllers
{
    public class UserController : Controller
    {
        public static string user;
        public readonly IEventService _serviceEvent;
        public readonly IUserService _serviceUser;
        public readonly ISeatService _serviceSeat;
        public readonly IReservationService _serviceRe;
        public readonly ITicketService _serviceTicket;
        public UserController(IEventService service1, IUserService service2, ISeatService service3, IReservationService service4, ITicketService service5)
        {
            _serviceEvent = service1;
            _serviceUser = service2;
            _serviceSeat = service3;
            _serviceRe = service4;
            _serviceTicket = service5;
        }
        public IActionResult Home()
        {
            return View();
        }

        public IActionResult Events()
        {
            var data = _serviceEvent.GetAll();
            return View(data);

        }

        public IActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Search(string name)
        {
            var re = _serviceRe.DisplayReservationByname(name);
            return View(re);
        }
        public IActionResult UserReservation()
        {
            // AccountController a = new AccountController(IUserService);
            if (user == null)
            {

                user = TempData["userName"].ToString();
            }
            var re = _serviceRe.DisplayReservationByname(user);
            return View(re);
        }

        

       /* public IActionResult EditReservation()
        {
            var t = _serviceSeat.AvailableSeat();
            return View(t);
        }*/

        public IActionResult ry(int id)
        {
            var r = _serviceTicket.DisplayTicket(id);
            return View(r);
        }

        
        [HttpPost]
        public IActionResult EditReservation(int id)
        {
            var t = _serviceSeat.GetSeatsById(id);
            return View(t);
            
        }

        [HttpPost]
        public IActionResult AddReservation(Reservation r)
        {
            _serviceRe.Add(r);

            return RedirectToAction("UserReservation");
        }
        [HttpPost]
        public IActionResult DeleteReservation(int id)
        {
            _serviceRe.Delete(id);
            return RedirectToAction("UserReservation");
        }
        public IActionResult AboutUs()
        {
            return View();
        }
    }
}
