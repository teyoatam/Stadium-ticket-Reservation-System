﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using SP_Project.Models;
using SP_Project.Models.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SP_Project.Controllers
{
    public class AccountController : Controller
    {
        public string name;
        public readonly IUserService _service;
        /*[ActivatorUtilitiesConstructor]
        public AccountController()
        {

        }*/
        public AccountController(IUserService service)
        {
            _service = service;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(User u)
        {
            
            //Session["username"] = u.userName;

            var role = _service.GetRole(u);
            

            if (role == "Adminstrator")
            {
                return View("~/Views/Admin/home.cshtml");
            }

            if (role == "User")
            {
                TempData["userName"] = u.userName;
                return RedirectToAction("UserReservation", "User");
            }
            return View("/Account/Register");
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(User u)
        {
            if (!ModelState.IsValid)
            {
                return View(u);
            }
            _service.Add(u);

            return RedirectToAction("Login");
            
        }
    }
}
